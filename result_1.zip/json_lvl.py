import json
import ast
import pandas as pd

df = pd.read_csv("eval_levels.csv")

levels = df['level']
json_levels = levels.apply(lambda x: ast.literal_eval(x))
json_levels = json_levels.to_list()

file_path = 'eval_levels.json'

# Save the JSON data to the file
with open(file_path, 'w') as file:
    json.dump(json_levels, file)

print(f'Saved {file_path}')